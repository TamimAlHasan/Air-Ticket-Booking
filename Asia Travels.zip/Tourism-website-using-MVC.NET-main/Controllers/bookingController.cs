﻿using AsiaTravels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AsiaTravels.Controllers
{
    public class bookingController : Controller
    {
        // GET: booking
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult book()
        {
            return View();
        }
        [HttpPost]
        public ActionResult book(booking book)
        {
            if (ModelState.IsValid)
            {
                using (travelEntities4 db = new travelEntities4())
                {

                    db.bookings.Add(book);
                    db.SaveChanges();
                }
                ModelState.Clear();
                ViewBag.Message =" successfully booked";
            }
            return View();
        }
    }
}